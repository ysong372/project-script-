# project_scripts
Hi, everyone, this is Rose's project repo. Have a lovely day and enjoy coding : )) 
# automised table look up 
This is an automised table look up script 
 
